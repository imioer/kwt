function timeout(btn)
{
    setTimeout(() => { btn.className = 'button' }, 1000)
    // setTimeout(() => btn.className = 'button', 1000) // skraceno
}

/*

"() => {}" je sintaksa za anonimnu funkciju, 
a od "function() {}" se razlikuje po 
tome sto nema implicitni parametar this 
(sto nam u ovom primeru nije ni potrebno)

ukoliko telo funkcije sadrzi samo jednu naredbu moze se zapisati i bez zagrada:
() => btn.className = 'button'

*/