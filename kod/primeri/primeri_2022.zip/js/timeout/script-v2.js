function timeout(btn)
{
    setTimeout(function() {
        btn.className = 'button'
    }, 1000)
}