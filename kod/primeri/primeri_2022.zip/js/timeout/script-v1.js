function timeout(btn)
{
    setTimeout(change, 1000, btn)
}

function change(btn) 
{
    btn.className = 'button'
}