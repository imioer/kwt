var xmlDoc;
var i = 0;
var cds;

function loadXMLDoc() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            xmlDoc = this.responseXML;
            cds = xmlDoc.getElementsByTagName("CD");
        }
    };
    xmlhttp.open("GET", "cd_catalog.xml", true);
    xmlhttp.send();
}

function showCDCatalog() {
    var table = "<tr><th>Artist</th><th>Title</th></tr>";
    var i;
    for (i=0; i<cds.length; i++) {
        table += "<tr onclick='displayCD(" + i + ")'><td>";
        var artist = cds[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue;
        var title = cds[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue;
        table += artist + "</td><td>" + title;
        table += "</td></tr>";
    }
    document.getElementById("demo").innerHTML = table;
}

function displayCD(i) {
    var artist = cds[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue;
    var title = cds[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue;
    var year = cds[i].getElementsByTagName("YEAR")[0].childNodes[0].nodeValue;
    document.getElementById("album").innerHTML =
        "Artist: " +
        artist +
        "<br>Title: " +
        title +
        "<br>Year: " + 
        year;
    
}

