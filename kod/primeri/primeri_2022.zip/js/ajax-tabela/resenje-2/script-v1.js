/* ============[ Verzija 1 - Inner HTML ]============ */

function showTable() 
{
    let cnt = document.getElementById('table-container')
    let rowsHTML = ''
    
    // Kreiranje stringa koji predstavlja HTML kod svih redova sa podacima
    for(let i = 0; i < catalog.length; i++) 
    {
        let cd = catalog[i]
        rowsHTML += `
            <tr onclick="showDetails(${i})">
                <td>${cd.artist}</td>
                <td>${cd.title}</td>
            </tr>
        `
    }

    // Kreiranje stringa koji predstavlja HTML kod cele tabele, sa hederom i sa podacima
    let tableHTML = `
        <table>
            <tr> 
                <th>Artist</th> 
                <th>Title</th> 
            </tr>
            ${rowsHTML}
        </table>
    `

    // Prilikom dodeljivanja string vrednosti innerHTML property-ju generisu
    // se elementi prema tom stringu (koji mora predstavljati validan HTML kod)
    cnt.innerHTML = tableHTML
}

function showDetails(i) 
{
    let cnt = document.getElementById('info-container')
    let cd = catalog[i]
    
    // Kreiranje stringa koji predstavlja HTML kod za podatke CD-a
    let infoHTML = `
        <div>
            <strong>Title: </strong>
            <span>${cd.title}</span>
        </div>
        <div>
            <strong>Artist: </strong>
            <span>${cd.artist}</span>
        </div>
        <div>
            <strong>Year: </strong>
            <span>${cd.year}</span>
        </div>
    `

    cnt.innerHTML = infoHTML
}