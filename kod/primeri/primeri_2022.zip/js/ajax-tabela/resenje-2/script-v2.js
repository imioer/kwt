/* ============[ Verzija 2 - DOM manipulacija ]============ */

function showTable() 
{
    let cnt = document.getElementById('table-container')
    let tbl = document.createElement('table')
    
    // Kreiranje elemenata za heder red
    let trH = document.createElement('tr')
    let thA = document.createElement('th')
    let thT = document.createElement('th')
    
    // Povezivanje elemenata u heder redu i dodavanje u tabelu
    trH.appendChild(thA)
    trH.appendChild(thT)
    tbl.appendChild(trH)
    
    // Dodela vrednosti hederima
    thA.innerText = 'Author'
    thT.innerText = 'Title'
    
    for(let cd of catalog)
    {
        // Kreiranje elemenata za red
        let tr = document.createElement('tr')
        let tdA = document.createElement('td')
        let tdT = document.createElement('td')
        
        // Povezivanje elemenata u redu i dodavanje u tabelu
        tr.appendChild(tdA)
        tr.appendChild(tdT)
        tbl.appendChild(tr)
        
        // Anonimna funkcija koja će se pozvati na klik elementa (tr)
        tr.onclick = function() {
            showDetails(cd) // ova funkcija će dobiri referencu na objekat CD-a
        }
        
        // Uzimanje podataka iz o objekta za CD i dodela vrednosti ćelijama
        tdA.innerText = cd.artist
        tdT.innerText = cd.title
    }

    // Ukoliko se u kontejneru već nalazi tabela skloniti je
    if(cnt.lastChild)
        cnt.lastChild.remove()
    
    // Dodavanje tabele u kontejner
    cnt.appendChild(tbl)
}

function showDetails(cd) 
{
    let cnt = document.getElementById('info-container')
    let div = document.createElement('div')

    // Kreiranje elemenata za sekciju sa informacijama o CD-u
    let divA = document.createElement('div')
    let divT = document.createElement('div')
    let divY = document.createElement('div')
    
    // Povezivanje novokreiranih elemenata
    div.appendChild(divT)
    div.appendChild(divA)
    div.appendChild(divY)
    
    // Uzimanje podataka iz o objekta za CD i dodela vrednosti elementima
    divA.innerText = 'Artist: ' + cd.artist
    divT.innerText = 'Title: ' + cd.title
    divY.innerText = 'Year: ' + cd.year
    
    // Ukoliko se u kontejneru već nalazi info o CD-u skloniti ga
    if(cnt.lastChild)
        cnt.lastChild.remove()
    
    // Dodavanje div-a sa podacima o CD-u u kontejner
    cnt.appendChild(div)
}