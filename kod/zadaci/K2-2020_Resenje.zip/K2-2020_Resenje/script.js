let cereals = []

let selElem = document.querySelector('select')
let txtElem = document.querySelector('input[type="text"]')

let cbs = document.querySelectorAll('input[type="checkbox"]')
let cbGt100 = cbs[0]
let cbLt100 = cbs[1]

let table = document.querySelector('#fold table')
let cart = document.querySelector('.wrapper table')

let priceElem = document.querySelector('.wrapper p')
let emptyElem = document.querySelector('.wrapper span')

function getData()
{
    let xhr = new XMLHttpRequest()
    
    xhr.onload = function() {
        if(this.status != 200) return

        let xmlCereals = xhr.responseXML.getElementsByTagName('Cereal')
        let regName = /^[0-9]/

        // Save list of objects with cereal data
        for (let xmlCereal of xmlCereals) 
        {
            let obj = {
                name:     xmlCereal.getElementsByTagName('Name')[0].textContent,
                manuf:    xmlCereal.getElementsByTagName('Manufacturer')[0].textContent,
                calories: Number(xmlCereal.getElementsByTagName('Calories')[0].textContent),
                price:    Number(xmlCereal.getElementsByTagName('Price')[0].textContent),
                inCart:  false
            }

            // Ubacuje samo objekat zitarice cije ime ne pocinje brojem
            if(regName.test(obj.name) == false)
                cereals.push(obj)
        }

        // Add distinct manufacturers to select element as options
        let manufs = []
        for(let cereal of cereals) {
            let index = manufs.findIndex((val) => cereal.manuf == val)
            let exist = index != -1
            if(!exist) {
                selElem.innerHTML += `
                    <option value="${cereal.manuf}">
                        ${cereal.manuf}
                    </option>
                `
                manufs.push(cereal.manuf)
            }
        }

        updateTable()
    }

    xhr.open('GET', 'Cereals.xml', true)
    xhr.send()
}

// Ubacuje u tabelu svaku zitaricu ciji podaci odgovaraju trenutno postavljenim filterima
function updateTable()
{
    table.innerHTML = ''
    for(let cereal of cereals) 
    {
        if(!matchFilter(cereal)) continue // <- koristi se funkcija matchFilter

        let row = document.createElement('tr')
        row.innerHTML = `
            <td>${cereal.name}</td>
            <td>${cereal.manuf}</td>
            <td>${cereal.calories}</td>
            <td>${cereal.price}</td>
        `

        let cb = document.createElement('input')
        cb.type = 'checkbox'
        cb.checked = cereal.inCart  // <- ukoliko je inCart postaljvne na true checkbox treba da bude cekiran
        
        // Kada se vrednost checkbox-a promeni (klikom na njega npr.) poziva se ova funkcija
        cb.onchange = function() {
            cereal.inCart = cb.checked  // <- promena stanja checkbox-a treba da se sacuva u objekat zitarice (u inCart)
            updateCart()
        }

        let td = document.createElement('td')
        td.appendChild(cb)
        row.appendChild(td)
        
        table.appendChild(row)
    }
}

// Ubacuje u cart listu sve zitarice koje imaju postavljen atribut toCart
function updateCart()
{
    let isEmpty = true
    let total = 0
    cart.innerHTML = ''
    
    for(let cereal of cereals) 
    {
        if(!cereal.inCart) continue
        
        cart.innerHTML += `
            <tr><td>${cereal.name}</td></tr>
        `
        total += cereal.price
        isEmpty = false
    }

    priceElem.innerHTML = total

    emptyElem.hidden = !isEmpty
}

// Vraca true ako podaci zitarice odgovaraju trenutno postavljenim filterima
function matchFilter(cer) 
{
    let okTxt = cer.name.indexOf(txtElem.value) != -1
    
    let okCal = (cbGt100.checked && cer.calories > 100) || 
                (cbLt100.checked && cer.calories <= 100) ||
                (cbLt100.checked == cbGt100.checked)
    
    let okMfr = (selElem.value == cer.manuf) ||
                (selElem.value == 'all')

    return okTxt && okCal && okMfr
}