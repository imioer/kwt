let myEmail = 'pera@mail.com'
let allMail = []
let selected = -1

fetchData()


function fetchData() {
    let xhr = new XMLHttpRequest()

    xhr.onload = function() {
        if (this.status != 200 && this.status != 304) return

        let doc = this.responseXML
        let mails = doc.getElementsByTagName('mail')

        for (const mail of mails) {
            let obj = {
                sender: mail.getElementsByTagName('sender')[0].textContent,
                receiver: mail.getElementsByTagName('receiver')[0].textContent,
                time: mail.getElementsByTagName('time')[0].textContent,
                title: mail.getElementsByTagName('title')[0].textContent,
                content: mail.getElementsByTagName('content')[0].textContent,
            }
            allMail.push(obj)
        }

        updateList()
        showDetails(0)
    }

    xhr.open('GET', 'data.xml', true)
    xhr.send()
}

function updateList() {
    let mailList = document.getElementById('mail-list')
    
    mailList.innerHTML = ''
    for (let i = 0; i < allMail.length; i++) {
        const mail = allMail[i]
        if (checkFilter(mail) == false) continue

        let emailStr = myEmail == mail.sender ? `to: ${mail.receiver}` : `from: ${mail.sender}`
        mailList.innerHTML += `
            <li ${i == selected ? 'class="selected"' : ''} onclick="showDetails(${i})">
                <h1>${mail.title}</h1>
                <em>${emailStr}</em>
                <span>${mail.time}</span>
            </li>
        `
    }
}

function showDetails(i) {
    selected = i
    updateList()

    let detailsElem = document.getElementById('details')
    let mail = allMail[i]
    
    let emailStr = myEmail == mail.sender ? `to: ${mail.receiver}` : `from: ${mail.sender}`
    detailsElem.innerHTML = `
        <h1>${mail.title}</h1>
        <em>${emailStr}</em>
        <span>${mail.time}</span>
        <p>${mail.content}</p>    
    `
}

function checkFilter(mail) {
    let text = document.getElementById('search').value
    let okContent = mail.content.indexOf(text) != -1
    let okTitle = mail.title.indexOf(text) != -1
    let okSender = mail.sender.indexOf(text) != -1
    let okReceiver = mail.receiver.indexOf(text) != -1

    return okContent || okTitle || okSender || okReceiver
}

function checkInputs() {
    let toInp = document.getElementById('inp-to')
    let toReg = /^[a-z0-9-.]+@[a-z0-9]{2,10}\.[a-z]{2,5}$/
    toInp.className = toReg.test(toInp.value) ? 'ok' : 'error'
    
    let titleInp = document.getElementById('inp-title')
    let titleReg = /^[A-Z].{2,29}$/
    titleInp.className = titleReg.test(titleInp.value) ? 'ok' : 'error'
    
    let contentInp = document.getElementById('inp-content')
    let contentReg = /^.{0,50}$/
    contentInp.className = contentReg.test(contentInp.value) ? 'ok' : 'error'
}